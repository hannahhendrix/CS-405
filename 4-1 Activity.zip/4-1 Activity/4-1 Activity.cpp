// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept> // For standard exceptions 

// Function that performs additional custom logic and throws a standard exception
bool do_even_more_custom_application_logic()
{

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // Throwing a standard exception to simulate an error condition
    throw std::runtime_error("Standard exception occured in do_even_more_custome_application_logic()");

    return true;
}

// Function that performs custom logic and handles exceptions from nested calls
void do_custom_application_logic()
{

    std::cout << "Running Custom Application Logic." << std::endl;

    try {

        // Attempt to call a function that may throw an exception
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }

    }
    catch (const std::exception& e) {
        // Catching and displaying the standard exception message
        std::cerr << "Caught exception: " << e.what() << std::endl;
    }

    // Define a custom exception class derived from std::exception
    class CustomException : public std::exception {
        const char* what() const noexcept override {
            return "Custom exception occurred in do_custom_application_logic()";
        }
    };

    // Throwing a custom exception to demonstrate custom exception handling
    throw CustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

// Function to divide two numbers, with error handling for division by zero
float divide(float num, float den)
{
    // Check for division by zero and throw an exception if detected
    if (den == 0) {
        throw std::invalid_argument("Division by zero error");
    }
    return (num / den);
}

// Function that calls the divide function and handles exceptions specific to division errors
void do_division() noexcept {
    float numerator = 10.0f;
    float denominator = 0;

    try {
        // Attempt to divide, which may throw an exception
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::invalid_argument& e) {
        // Catching and displaying the division by zero error message
        std::cerr << "Error: " << e.what() << std::endl;
    }
}

// Main function that wraps all functionality and handles any uncaught exceptions
int main() {
    std::cout << "Exceptions Tests!" << std::endl;

    try {
        // Call functions that may throw exceptions
        do_division();
        do_custom_application_logic();
    }
    catch (const std::exception& e) {
        // Catch any standard exceptions not handled earlier and display their messages
        std::cerr << "Unhandled standard exception: " << e.what() << std::endl;
    }
    catch (...) {
        // Catch any other unknown exceptions
        std::cerr << "Unhandled unknown exception caught!" << std::endl;
    }

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
