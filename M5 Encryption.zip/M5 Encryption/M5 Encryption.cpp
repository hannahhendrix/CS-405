// Encryption.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>

/// <summary>
/// encrypt or decrypt a source string using the provided key
/// </summary>
/// <param name="source">input string to process</param>
/// <param name="key">key to use in encryption / decryption</param>
/// <returns>transformed string</returns>
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    // Get the lengths of the key and source to avoid repeated calls to the `.length()` method.
    const auto key_length = key.length();
    const auto source_length = source.length();

    // Ensure that the key and source are non-empty. The program should not proceed otherwise.
    assert(key_length > 0);
    assert(source_length > 0);

    // Start with the source string as the output, which will be modified in place.
    std::string output = source;

    // Iterate over each character in the source string.
    for (size_t i = 0; i < source_length; ++i)
    {
        // Perform XOR encryption. The key index is wrapped using modulo to handle varying lengths.
        output[i] = source[i] ^ key[i % key_length];
    }

    // Double-check that the output length matches the input source length.
    assert(output.length() == source_length);

    // Return the transformed string.
    return output;
}

std::string read_file(const std::string& filename)
{
    // Open the file for reading.
    std::ifstream infile(filename);

    // Throw an exception if the file cannot be opened.
    if (!infile)
    {
        throw std::runtime_error("Could not open file for reading: " + filename);
    }

    // Use a string stream to read the entire file content.
    std::ostringstream buffer;
    buffer << infile.rdbuf();

    // Return the file content as a string.
    return buffer.str();
}

std::string get_student_name(const std::string& string_data)
{
    std::string student_name;

    // find the first newline
    size_t pos = string_data.find('\n');
    // did we find a newline
    if (pos != std::string::npos)
    { // we did, so copy that substring as the student name
        student_name = string_data.substr(0, pos);
    }

    return student_name;
}

void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data)
{
    // Open the file for writing.
    std::ofstream outfile(filename);

    // Throw an exception if the file cannot be opened.
    if (!outfile)
    {
        throw std::runtime_error("Could not open file for writing: " + filename);
    }

    // Get the current timestamp in yyyy-mm-dd format using localtime_s.
    std::time_t t = std::time(nullptr);
    std::tm tm;
    if (localtime_s(&tm, &t) != 0)
    {
        throw std::runtime_error("Failed to get local time");
    }
    std::ostringstream date_stream;
    date_stream << std::put_time(&tm, "%Y-%m-%d");

    // Write the data to the file in the required format:
    // Line 1: Student's name
    // Line 2: Current date
    // Line 3: Encryption key
    // Line 4+: Data
    outfile << student_name << "\n"
        << date_stream.str() << "\n"
        << key << "\n"
        << data << "\n";
}

int main()
{
    std::cout << "Encryption Decryption Test!" << std::endl;

    // Define the file names used for the test.
    const std::string file_name = "inputdatafile.txt"; // Input file containing plain text
    const std::string encrypted_file_name = "encrypteddatafile.txt"; // File to save encrypted data
    const std::string decrypted_file_name = "decrypteddatafile.txt"; // File to save decrypted data
    const std::string key = "password"; // Encryption key

    try
    {
        // Step 1: Read the source string from the input file.
        const std::string source_string = read_file(file_name);

        // Step 2: Extract the student's name from the source data.
        const std::string student_name = get_student_name(source_string);

        // Step 3: Encrypt the source string using the XOR method.
        const std::string encrypted_string = encrypt_decrypt(source_string, key);

        // Step 4: Save the encrypted string to the encrypted file.
        save_data_file(encrypted_file_name, student_name, key, encrypted_string);

        // Step 5: Decrypt the encrypted string using the XOR method.
        const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);

        // Step 6: Save the decrypted string to the decrypted file.
        save_data_file(decrypted_file_name, student_name, key, decrypted_string);

        // Print a summary of operations.
        std::cout << "Read File: " << file_name
            << " - Encrypted To: " << encrypted_file_name
            << " - Decrypted To: " << decrypted_file_name << std::endl;
    }
    catch (const std::exception& ex)
    {
        // Catch and report any errors that occur during the process.
        std::cerr << "Error: " << ex.what() << std::endl;
    }

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
