
#include "pch.h"

class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};


// Test that a collection is created and not null
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull) {
    ASSERT_TRUE(collection);
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created
TEST_F(CollectionTest, IsEmptyOnCreate) {
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

// Test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector) {
    ASSERT_EQ(collection->size(), 0);
    add_entries(1);
    EXPECT_EQ(collection->size(), 1);
}

// Test to verify adding five values to the collection
TEST_F(CollectionTest, CanAddFiveValuesToVector) {
    add_entries(5);
    EXPECT_EQ(collection->size(), 5);
}

// Test to verify max_size is greater or equal to size
TEST_F(CollectionTest, MaxSizeGreaterOrEqualSize) {
    EXPECT_GE(collection->max_size(), collection->size());
    add_entries(10);
    EXPECT_GE(collection->max_size(), collection->size());
}

// Test to verify capacity is greater or equal to size
TEST_F(CollectionTest, CapacityGreaterOrEqualSize) {
    EXPECT_GE(collection->capacity(), collection->size());
    add_entries(10);
    EXPECT_GE(collection->capacity(), collection->size());
}

// Test to verify resizing increases the collection
TEST_F(CollectionTest, ResizeIncreasesCollection) {
    collection->resize(5);
    EXPECT_EQ(collection->size(), 5);
}

// Test to verify resizing decreases the collection
TEST_F(CollectionTest, ResizeDecreasesCollection) {
    add_entries(10);
    collection->resize(5);
    EXPECT_EQ(collection->size(), 5);
}

// Test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, ResizeToZero) {
    add_entries(5);
    collection->resize(0);
    EXPECT_TRUE(collection->empty());
}

// Test to verify clear erases the collection
TEST_F(CollectionTest, ClearErasesCollection) {
    add_entries(5);
    collection->clear();
    EXPECT_TRUE(collection->empty());
}

// Test to verify erase(begin, end) erases the collection
TEST_F(CollectionTest, EraseBeginToEnd) {
    add_entries(5);
    collection->erase(collection->begin(), collection->end());
    EXPECT_TRUE(collection->empty());
}

// Test to verify reserve increases capacity but not size
TEST_F(CollectionTest, ReserveIncreasesCapacity) {
    size_t originalCapacity = collection->capacity();
    collection->reserve(originalCapacity + 10);
    EXPECT_GT(collection->capacity(), originalCapacity);
    EXPECT_EQ(collection->size(), 0);
}

// Negative test: Verify out_of_range exception is thrown for invalid index
TEST_F(CollectionTest, ThrowOutOfRangeForInvalidIndex) {
    EXPECT_THROW(collection->at(0), std::out_of_range);
}

// Custom Positive Test: Verify elements remain correct after resizing up
TEST_F(CollectionTest, ValuesRemainAfterResizingUp) {
    collection->push_back(42);
    collection->resize(5);
    EXPECT_EQ(collection->at(0), 42);
}

// Custom Negative Test: Access invalid element in non-empty collection
TEST_F(CollectionTest, AccessInvalidElementThrows) {
    collection->push_back(10);
    EXPECT_THROW(collection->at(5), std::out_of_range);
}